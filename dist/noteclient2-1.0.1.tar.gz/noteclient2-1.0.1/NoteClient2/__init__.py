from .client import NoteClient2

__all__ = ["NoteClient2"]
__version__ = "1.0.1"