# Changelog

## 1.0.0
- Initial release
- Support: markdown -> free/pay body, images, eyecatch, magazines